import scrapy


class HarrypottarSpider(scrapy.Spider):
    name = "harryPottar"
    allowed_domains = ["www.wbstudiotour.jp"]
    start_urls = ["https://www.wbstudiotour.jp/"]

    def parse(self, response):
        pass
